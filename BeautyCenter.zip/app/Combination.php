<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Combination extends Model
{
    protected $table = 'combinations';
    protected $fillable = ['title'];

}
