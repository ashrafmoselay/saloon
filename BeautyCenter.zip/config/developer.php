<?php

return [



// 'appname_ar'=>'سهل للحسابات',

// 'appname_en'=>'SAHAL POS',

// 'logo'=>'sahallogo.png',

//'logoStyle'=>'width: 180px;',

//'mainImg'=>'loginbg.png',

//'mainImgStyle' => 'margin-top: 70px;',

// 'certification'=>'بكالوريوس كلية حاسبات ومعلومات - جامعة القاهرة',

// 'developer_en'=>'Eng/ Ashraf Hassan',

// 'developer_ar'=>'م/ أشرف حسان',

// 'mobile'=>'01061048481 - 01032845323',

// 'address'=>'ابو رجوان البحرى - البدرشين - الجيزة',

// 'email'=>'ashrafhassan42@yahoo.com',

//'website'=>''


'appname_ar'=>'لاين للحسابات',

'appname_en'=>'MLine',

'logo'=>'mline.png',//'sahallogo.png',

'logoStyle'=>'width: 70px;position: absolute;bottom: -73px;left: 0;',

'mainImg'=>'loginbg.png',

'mainImgStyle' => 'margin-top: 70px;',

'certification'=>'',

'developer_en'=>'خط الالفية لتقنية المعلومات',

'developer_ar'=>'خط الالفية لتقنية المعلومات',

'mobile'=>'0550104684',

'address'=>'جدة',

'email'=>'sales@mline-sa.net',

'website'=>'https://mline-sa.net'



/*'appname_ar'=>'Elected POS',

'appname_en'=>'Elected POS',

'logo'=>'logo.png',

'developer_en'=>'Elected Apps',

'developer_ar'=>'إليكتيد أبس',

'mobile'=>'50499919',

'address'=>'الكويت - برج الخالد',

'email'=>'info@electedapps.com',

'website'=>'http://electedapps.com'*/


/*'appname_ar'=>'إيزى أبس',

'appname_en'=>'Easy Apps',

'logo'=>'easyappslogo.jpg',

'developer_en'=>'Easy Apps',

'developer_ar'=>'إيزى أبس',

'mobile'=>'م/محمد: 01090412131 - 01221875030 / م/حمدى: 01018047318',

'address'=>'2 شارع أحمد الكداح متفرع من شارع طه حسين - النزهة الجديدة - القاهرة',

'email'=>'owner@icashier-eg.com',

'website'=>'http://easyapps-eg.com'*/
];
