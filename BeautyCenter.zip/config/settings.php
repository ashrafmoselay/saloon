<?php
 // generated at 2019-03-31 21:19:00 
return array (
  'SiteName' => 'الطائـــــف للمواد الغذائية',
  'Address' => 'العنوان : أبو رجوان البحرى - بدرشين - جيزة',
  'mobile' => 'التليفون : 01114323535 - 01100434867 - 01018813008',
  'show_cost_price' => '1',
  'canChangePrice' => '1',
  'showImage' => '2',
  'show_profit_button' => '1',
  'can_order_unavilable_qty' => '2',
  'sales_marketer' => '2',
  'industrial' => '1',
  'show_category_in_invoice' => '2',
  'show_stores_in_invoices' => '2',
  'PrintSize' => '12',
);