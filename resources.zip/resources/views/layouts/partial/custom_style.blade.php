<style>
    .skin-blue .main-header .logo,
    .skin-blue .main-header .navbar,.main-header{
        background-color: #4267b2;
    }
    .skin-blue .main-header .logo:hover,
    .skin-blue .main-header .navbar .sidebar-toggle:hover {
        background: rgba(0, 0, 0, 0.1);
        color: #f6f6f6;
    }

</style>
